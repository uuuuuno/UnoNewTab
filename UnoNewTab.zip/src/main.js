import './app.css';
import App from './App.svelte';

export default new App({
  target: document.getElementById('app')
});
